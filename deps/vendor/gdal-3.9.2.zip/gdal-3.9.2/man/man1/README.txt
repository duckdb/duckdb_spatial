Man pages are not not present in the git repository. They are generated
at release preparation time by the mkgdaldist.sh script
